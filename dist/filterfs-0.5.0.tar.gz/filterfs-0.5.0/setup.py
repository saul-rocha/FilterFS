from setuptools import setup

with open("README.md", "r") as fh:
    readme = fh.read()

setup(name='filterfs',
    version='0.5.0',
    url='https://github.com/saul-rocha/FilterFS.git',
    license='MIT License',
    author='Saul Rocha',
    long_description=readme,
    long_description_content_type="text/markdown",
    author_email='saul.rocha2001@gmail.com',
    keywords='Pacote',
    description=u'um pacote que modifica imagens rgb para canais de imagens LUV, aplica os filtros gray, gaussiano, clahe, equalização de histograma e bordas de objetos nas imagens em uma determianda pasta com N imagens',
    packages=['src'],
    install_requires=['numpy','pyplot', 'skimage', 'matplotlib', 'glob', 'cv2'],)